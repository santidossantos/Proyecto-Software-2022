<template>
    <MiPerfil />
</template>

<script>
import MiPerfil from "@/components/MiPerfil.vue";

export default {
  name: "MiPerfilView",
  components: {
    MiPerfil,
  },
};
</script>
