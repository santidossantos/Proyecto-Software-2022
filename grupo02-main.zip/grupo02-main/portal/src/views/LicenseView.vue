<template>
    <License />
</template>


<script>
import License from "@/components/License.vue";

export default {
    name: "LicenseView",
    components: {
        License,
    },
};
</script>


<style>
    @import "@/assets/license.css";
</style>
